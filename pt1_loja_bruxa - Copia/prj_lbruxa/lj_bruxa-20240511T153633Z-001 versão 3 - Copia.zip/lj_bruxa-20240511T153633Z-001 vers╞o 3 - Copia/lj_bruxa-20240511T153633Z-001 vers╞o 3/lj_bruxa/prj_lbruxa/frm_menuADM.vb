﻿Public Class frm_menuADM
    Private Sub frm_menuADM_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class