﻿Public Class frm_cadastro
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco_sql_server()
        frm_login.Hide()
        Me.Show()
    End Sub

    Private Sub btn_ok_Click(sender As Object, e As EventArgs) Handles btn_ok.Click
        Try
            sql = "select * from tab_cadastro where cpf = '" & txt_cpf.Text & "'"
            rs = db.Execute(sql)
            If rs.EOF = False Then
                MsgBox("CPF já cadastrado", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
            Else
                sql = "insert into tab_cadastro(nome,cpf,nascimento,telefone,senha,email) values ('" & txt_nome.Text & "', '" & txt_cpf.Text & "', '" & txt_nasc.Text & "', '" & txt_tel.Text & "', '" & txt_senha.Text & "', '" & txt_email.Text & "')"
                rs = db.Execute(sql)
                MsgBox("Cadastro realizado!", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
                txt_nome.Clear()
                txt_cpf.Clear()
                txt_nasc.Clear()
                txt_tel.Clear()
                txt_senha.Clear()
                txt_email.Clear()
                txt_nome.Focus()
            End If
        Catch ex As Exception
            MsgBox("Erro ao cadastrar.", MsgBoxStyle.Information + MsgBoxStyle.OkOnly, "AVISO")
        End Try
    End Sub

End Class