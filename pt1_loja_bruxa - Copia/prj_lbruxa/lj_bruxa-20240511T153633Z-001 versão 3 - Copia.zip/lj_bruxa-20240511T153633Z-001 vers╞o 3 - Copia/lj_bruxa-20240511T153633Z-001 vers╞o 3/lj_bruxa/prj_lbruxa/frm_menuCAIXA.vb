﻿Public Class frm_menuCAIXA
    Private Sub frm_menuCAIXA_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        conecta_banco_sql_server()
        Me.Show()
        frm_login.Hide()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btn_sair.Click
        End
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_deslogar.Click
        frm_login.Show()
        Me.Hide()
    End Sub
End Class