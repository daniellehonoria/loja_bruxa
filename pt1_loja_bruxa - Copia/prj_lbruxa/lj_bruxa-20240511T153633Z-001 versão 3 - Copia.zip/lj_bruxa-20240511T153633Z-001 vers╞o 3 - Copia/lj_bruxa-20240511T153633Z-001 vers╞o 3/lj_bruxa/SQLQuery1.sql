create database cad_user;
use cad_user;
create table tab_cadastro (
id_user int identity(1,1) not null primary key,
nome varchar(60),
cpf varchar(14),
nascimento varchar(8),
email varchar(40),
telefone varchar(12));

select * from tab_cadastro;